# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

[CmdletBinding()]
param (
    [Parameter()]
    [string]$extensions
)

function Get-CacheFilePath {
    if ($IsWindows) {
        Join-Path $env:LocalAppData "dsc\PowerShellDiscoverCache.json"
    } else {
        Join-Path $env:HOME ".dsc" "PowerShellDiscoverCache.json"
    }
}

function Test-CacheValid {
    param([string]$CacheFilePath, [string[]]$PSPaths)

    if (-not (Test-Path $CacheFilePath)) {
        return $false
    }

    try {
        $cache = Get-Content -Raw $CacheFilePath | ConvertFrom-Json

        foreach ($entry in $cache.PathInfo.PSObject.Properties) {
            $path = $entry.Name
            if (-not (Test-Path $path)) {
                return $false
            }

            $currentLastWrite = (Get-Item $path).LastWriteTimeUtc
            $cachedLastWrite = [DateTime]$entry.Value

            if ($currentLastWrite -ne $cachedLastWrite) {
                return $false
            }
        }

        $cachedPaths = [string[]]$cache.PSModulePaths
        if ($cachedPaths.Count -ne $PSPaths.Count) {
            return $false
        }

        $diff = Compare-Object $cachedPaths $PSPaths
        if ($null -ne $diff) {
            return $false
        }

        foreach ($manifest in $cache.Manifests) {
            if (-not (Test-Path -LiteralPath $manifest.manifestPath)) {
                return $false
            }
        }

        return $true
    } catch {
        return $false
    }
}

function Invoke-DscResourceDiscovery {
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$extensions
    )

    begin {
        $psPaths = $env:PSModulePath -split [System.IO.Path]::PathSeparator | Where-Object { $_ -notmatch 'WindowsPowerShell' }

        $cacheFilePath = Get-CacheFilePath
        $useCache = Test-CacheValid -CacheFilePath $cacheFilePath -PSPaths $psPaths
    }
    process {
        if ($useCache) {
            $cache = Get-Content -Raw $cacheFilePath | ConvertFrom-Json
            $manifests = $cache.Manifests
        } else {
            $manifests = $psPaths | ForEach-Object -Parallel {
                $searchPatterns = [System.Collections.Generic.List[string]]::new()
                foreach ($extension in ($using:extensions).Split(',')) {
                    $searchPatterns.Add('*' + $extension)
                }
                $enumOptions = [System.IO.EnumerationOptions]@{ IgnoreInaccessible = $true; RecurseSubdirectories = $true }
                foreach ($pattern in $searchPatterns) {
                    try {
                        [System.IO.Directory]::EnumerateFiles($_, $pattern, $enumOptions) | ForEach-Object {
                            @{ manifestPath = $_ }
                        }
                    } catch { }
                }
            } -ThrottleLimit 10

            $pathInfo = @{}
            foreach ($path in $psPaths) {
                $item = Get-Item -LiteralPath $path -ErrorAction Ignore
                if ($item) {
                    $pathInfo[$path] = $item.LastWriteTimeUtc
                    # Track each module subdirectory so that manifest changes inside an
                    # already-known module are detected, even if the parent directory timestamp isn't updated.
                    Get-ChildItem -LiteralPath $path -Directory -ErrorAction Ignore | ForEach-Object {
                        $pathInfo[$_.FullName] = $_.LastWriteTimeUtc
                    }
                }
            }

            $cacheObject = @{
                PSModulePaths = $psPaths
                PathInfo      = $pathInfo
                Manifests     = $manifests
            }

            $cacheDir = Split-Path $cacheFilePath -Parent
            if (-not (Test-Path $cacheDir)) {
                New-Item -ItemType Directory -Path $cacheDir -Force | Out-Null
            }

            $cacheObject | ConvertTo-Json -Depth 10 | Set-Content -Path $cacheFilePath -Force
        }
    }
    end {
        if ($manifests.Count -gt 0) {
            $manifests | ForEach-Object { $_ | ConvertTo-Json -Compress }
        }
    }
}

Invoke-DscResourceDiscovery -extensions $extensions
